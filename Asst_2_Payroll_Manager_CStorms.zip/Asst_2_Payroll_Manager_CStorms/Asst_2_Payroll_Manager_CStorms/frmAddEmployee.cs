﻿/*****************************************************************************************************************************
*  
*  Author:     Carl G Storms
*              July 2019
*
*  Purpose:    Class Assigment #2 - University of Calgary
*                                   Continuing Education
*                                   ICT 711 - Computer Programming Level 2
*
*  Description:    
*
*                  Expected Behaviour - 
*                             
*****************************************************************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Asst_2_Payroll_Manager_CStorms
{
    public partial class frmAddEmployee : Form
    {
        public frmAddEmployee()
        {
            InitializeComponent();
        }

        private void txtHourlyRate_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
