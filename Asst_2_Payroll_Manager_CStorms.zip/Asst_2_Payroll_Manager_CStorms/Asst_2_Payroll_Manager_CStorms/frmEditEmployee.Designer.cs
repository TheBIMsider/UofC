﻿namespace Asst_2_Payroll_Manager_CStorms
{
    partial class frmEditEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditEmployee));
            this.btnCancelEE = new System.Windows.Forms.Button();
            this.btnUpdateEE = new System.Windows.Forms.Button();
            this.gbxTimesheetDataEE = new System.Windows.Forms.GroupBox();
            this.txtSaturdayEE = new System.Windows.Forms.TextBox();
            this.txtMondayEE = new System.Windows.Forms.TextBox();
            this.txtTuesdayEE = new System.Windows.Forms.TextBox();
            this.txtWednesdayEE = new System.Windows.Forms.TextBox();
            this.txtThursdayEE = new System.Windows.Forms.TextBox();
            this.txtFridayEE = new System.Windows.Forms.TextBox();
            this.txtSundayEE = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxPersonalInformationEE = new System.Windows.Forms.GroupBox();
            this.labHourlyRate = new System.Windows.Forms.Label();
            this.labLastName = new System.Windows.Forms.Label();
            this.labFirstName = new System.Windows.Forms.Label();
            this.txtHourlyRateEE = new System.Windows.Forms.TextBox();
            this.txtLastNameEE = new System.Windows.Forms.TextBox();
            this.txtFirstNameEE = new System.Windows.Forms.TextBox();
            this.gbxTimesheetDataEE.SuspendLayout();
            this.gbxPersonalInformationEE.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancelEE
            // 
            this.btnCancelEE.Location = new System.Drawing.Point(296, 276);
            this.btnCancelEE.Name = "btnCancelEE";
            this.btnCancelEE.Size = new System.Drawing.Size(75, 23);
            this.btnCancelEE.TabIndex = 7;
            this.btnCancelEE.Text = "Cancel";
            this.btnCancelEE.UseVisualStyleBackColor = true;
            // 
            // btnUpdateEE
            // 
            this.btnUpdateEE.Location = new System.Drawing.Point(198, 276);
            this.btnUpdateEE.Name = "btnUpdateEE";
            this.btnUpdateEE.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateEE.TabIndex = 6;
            this.btnUpdateEE.Text = "Update";
            this.btnUpdateEE.UseVisualStyleBackColor = true;
            // 
            // gbxTimesheetDataEE
            // 
            this.gbxTimesheetDataEE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxTimesheetDataEE.Controls.Add(this.txtSaturdayEE);
            this.gbxTimesheetDataEE.Controls.Add(this.txtMondayEE);
            this.gbxTimesheetDataEE.Controls.Add(this.txtTuesdayEE);
            this.gbxTimesheetDataEE.Controls.Add(this.txtWednesdayEE);
            this.gbxTimesheetDataEE.Controls.Add(this.txtThursdayEE);
            this.gbxTimesheetDataEE.Controls.Add(this.txtFridayEE);
            this.gbxTimesheetDataEE.Controls.Add(this.txtSundayEE);
            this.gbxTimesheetDataEE.Controls.Add(this.label7);
            this.gbxTimesheetDataEE.Controls.Add(this.label6);
            this.gbxTimesheetDataEE.Controls.Add(this.label5);
            this.gbxTimesheetDataEE.Controls.Add(this.label4);
            this.gbxTimesheetDataEE.Controls.Add(this.label3);
            this.gbxTimesheetDataEE.Controls.Add(this.label2);
            this.gbxTimesheetDataEE.Controls.Add(this.label1);
            this.gbxTimesheetDataEE.Location = new System.Drawing.Point(19, 163);
            this.gbxTimesheetDataEE.Name = "gbxTimesheetDataEE";
            this.gbxTimesheetDataEE.Size = new System.Drawing.Size(352, 84);
            this.gbxTimesheetDataEE.TabIndex = 5;
            this.gbxTimesheetDataEE.TabStop = false;
            this.gbxTimesheetDataEE.Text = "Timesheet Data";
            // 
            // txtSaturdayEE
            // 
            this.txtSaturdayEE.Location = new System.Drawing.Point(285, 50);
            this.txtSaturdayEE.Name = "txtSaturdayEE";
            this.txtSaturdayEE.Size = new System.Drawing.Size(36, 20);
            this.txtSaturdayEE.TabIndex = 13;
            // 
            // txtMondayEE
            // 
            this.txtMondayEE.Location = new System.Drawing.Point(75, 50);
            this.txtMondayEE.Name = "txtMondayEE";
            this.txtMondayEE.Size = new System.Drawing.Size(36, 20);
            this.txtMondayEE.TabIndex = 12;
            // 
            // txtTuesdayEE
            // 
            this.txtTuesdayEE.Location = new System.Drawing.Point(117, 50);
            this.txtTuesdayEE.Name = "txtTuesdayEE";
            this.txtTuesdayEE.Size = new System.Drawing.Size(36, 20);
            this.txtTuesdayEE.TabIndex = 11;
            // 
            // txtWednesdayEE
            // 
            this.txtWednesdayEE.Location = new System.Drawing.Point(159, 50);
            this.txtWednesdayEE.Name = "txtWednesdayEE";
            this.txtWednesdayEE.Size = new System.Drawing.Size(36, 20);
            this.txtWednesdayEE.TabIndex = 10;
            // 
            // txtThursdayEE
            // 
            this.txtThursdayEE.Location = new System.Drawing.Point(201, 50);
            this.txtThursdayEE.Name = "txtThursdayEE";
            this.txtThursdayEE.Size = new System.Drawing.Size(36, 20);
            this.txtThursdayEE.TabIndex = 9;
            // 
            // txtFridayEE
            // 
            this.txtFridayEE.Location = new System.Drawing.Point(243, 50);
            this.txtFridayEE.Name = "txtFridayEE";
            this.txtFridayEE.Size = new System.Drawing.Size(36, 20);
            this.txtFridayEE.TabIndex = 8;
            // 
            // txtSundayEE
            // 
            this.txtSundayEE.Location = new System.Drawing.Point(33, 50);
            this.txtSundayEE.Name = "txtSundayEE";
            this.txtSundayEE.Size = new System.Drawing.Size(36, 20);
            this.txtSundayEE.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(80, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Mon";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(293, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Sat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(253, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Fri";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(206, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Thu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(163, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Wed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tue";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sun";
            // 
            // gbxPersonalInformationEE
            // 
            this.gbxPersonalInformationEE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxPersonalInformationEE.Controls.Add(this.labHourlyRate);
            this.gbxPersonalInformationEE.Controls.Add(this.labLastName);
            this.gbxPersonalInformationEE.Controls.Add(this.labFirstName);
            this.gbxPersonalInformationEE.Controls.Add(this.txtHourlyRateEE);
            this.gbxPersonalInformationEE.Controls.Add(this.txtLastNameEE);
            this.gbxPersonalInformationEE.Controls.Add(this.txtFirstNameEE);
            this.gbxPersonalInformationEE.Location = new System.Drawing.Point(19, 16);
            this.gbxPersonalInformationEE.Name = "gbxPersonalInformationEE";
            this.gbxPersonalInformationEE.Size = new System.Drawing.Size(353, 134);
            this.gbxPersonalInformationEE.TabIndex = 4;
            this.gbxPersonalInformationEE.TabStop = false;
            this.gbxPersonalInformationEE.Text = "Personal Information";
            // 
            // labHourlyRate
            // 
            this.labHourlyRate.AutoSize = true;
            this.labHourlyRate.Location = new System.Drawing.Point(19, 100);
            this.labHourlyRate.Name = "labHourlyRate";
            this.labHourlyRate.Size = new System.Drawing.Size(66, 13);
            this.labHourlyRate.TabIndex = 5;
            this.labHourlyRate.Text = "Hourly Rate:";
            // 
            // labLastName
            // 
            this.labLastName.AutoSize = true;
            this.labLastName.Location = new System.Drawing.Point(19, 69);
            this.labLastName.Name = "labLastName";
            this.labLastName.Size = new System.Drawing.Size(61, 13);
            this.labLastName.TabIndex = 4;
            this.labLastName.Text = "Last Name:";
            // 
            // labFirstName
            // 
            this.labFirstName.AutoSize = true;
            this.labFirstName.Location = new System.Drawing.Point(19, 37);
            this.labFirstName.Name = "labFirstName";
            this.labFirstName.Size = new System.Drawing.Size(60, 13);
            this.labFirstName.TabIndex = 3;
            this.labFirstName.Text = "First Name:";
            // 
            // txtHourlyRateEE
            // 
            this.txtHourlyRateEE.Location = new System.Drawing.Point(128, 97);
            this.txtHourlyRateEE.Name = "txtHourlyRateEE";
            this.txtHourlyRateEE.Size = new System.Drawing.Size(100, 20);
            this.txtHourlyRateEE.TabIndex = 2;
            // 
            // txtLastNameEE
            // 
            this.txtLastNameEE.Location = new System.Drawing.Point(128, 66);
            this.txtLastNameEE.Name = "txtLastNameEE";
            this.txtLastNameEE.Size = new System.Drawing.Size(200, 20);
            this.txtLastNameEE.TabIndex = 1;
            // 
            // txtFirstNameEE
            // 
            this.txtFirstNameEE.Location = new System.Drawing.Point(128, 34);
            this.txtFirstNameEE.Name = "txtFirstNameEE";
            this.txtFirstNameEE.Size = new System.Drawing.Size(200, 20);
            this.txtFirstNameEE.TabIndex = 0;
            // 
            // frmEditEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 311);
            this.Controls.Add(this.btnCancelEE);
            this.Controls.Add(this.btnUpdateEE);
            this.Controls.Add(this.gbxTimesheetDataEE);
            this.Controls.Add(this.gbxPersonalInformationEE);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmEditEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Edit Employee";
            this.gbxTimesheetDataEE.ResumeLayout(false);
            this.gbxTimesheetDataEE.PerformLayout();
            this.gbxPersonalInformationEE.ResumeLayout(false);
            this.gbxPersonalInformationEE.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancelEE;
        private System.Windows.Forms.Button btnUpdateEE;
        private System.Windows.Forms.GroupBox gbxTimesheetDataEE;
        private System.Windows.Forms.TextBox txtSaturdayEE;
        private System.Windows.Forms.TextBox txtMondayEE;
        private System.Windows.Forms.TextBox txtTuesdayEE;
        private System.Windows.Forms.TextBox txtWednesdayEE;
        private System.Windows.Forms.TextBox txtThursdayEE;
        private System.Windows.Forms.TextBox txtFridayEE;
        private System.Windows.Forms.TextBox txtSundayEE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbxPersonalInformationEE;
        private System.Windows.Forms.Label labHourlyRate;
        private System.Windows.Forms.Label labLastName;
        private System.Windows.Forms.Label labFirstName;
        private System.Windows.Forms.TextBox txtHourlyRateEE;
        private System.Windows.Forms.TextBox txtLastNameEE;
        private System.Windows.Forms.TextBox txtFirstNameEE;
    }
}