﻿namespace Asst_2_Payroll_Manager_CStorms
{
    partial class frmEnterTimesheetData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEnterTimesheetData));
            this.btnCancelETD = new System.Windows.Forms.Button();
            this.btnUpdateETD = new System.Windows.Forms.Button();
            this.gbxTimesheetDataETD = new System.Windows.Forms.GroupBox();
            this.txtSaturdayETD = new System.Windows.Forms.TextBox();
            this.txtMondayETD = new System.Windows.Forms.TextBox();
            this.txtTuesdayETD = new System.Windows.Forms.TextBox();
            this.txtWednesdayETD = new System.Windows.Forms.TextBox();
            this.txtThursdayETD = new System.Windows.Forms.TextBox();
            this.txtFridayETD = new System.Windows.Forms.TextBox();
            this.txtSundayETD = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxTimesheetDataETD.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancelETD
            // 
            this.btnCancelETD.Location = new System.Drawing.Point(296, 126);
            this.btnCancelETD.Name = "btnCancelETD";
            this.btnCancelETD.Size = new System.Drawing.Size(75, 23);
            this.btnCancelETD.TabIndex = 6;
            this.btnCancelETD.Text = "Cancel";
            this.btnCancelETD.UseVisualStyleBackColor = true;
            // 
            // btnUpdateETD
            // 
            this.btnUpdateETD.Location = new System.Drawing.Point(198, 126);
            this.btnUpdateETD.Name = "btnUpdateETD";
            this.btnUpdateETD.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateETD.TabIndex = 5;
            this.btnUpdateETD.Text = "Update";
            this.btnUpdateETD.UseVisualStyleBackColor = true;
            // 
            // gbxTimesheetDataETD
            // 
            this.gbxTimesheetDataETD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxTimesheetDataETD.Controls.Add(this.txtSaturdayETD);
            this.gbxTimesheetDataETD.Controls.Add(this.txtMondayETD);
            this.gbxTimesheetDataETD.Controls.Add(this.txtTuesdayETD);
            this.gbxTimesheetDataETD.Controls.Add(this.txtWednesdayETD);
            this.gbxTimesheetDataETD.Controls.Add(this.txtThursdayETD);
            this.gbxTimesheetDataETD.Controls.Add(this.txtFridayETD);
            this.gbxTimesheetDataETD.Controls.Add(this.txtSundayETD);
            this.gbxTimesheetDataETD.Controls.Add(this.label7);
            this.gbxTimesheetDataETD.Controls.Add(this.label6);
            this.gbxTimesheetDataETD.Controls.Add(this.label5);
            this.gbxTimesheetDataETD.Controls.Add(this.label4);
            this.gbxTimesheetDataETD.Controls.Add(this.label3);
            this.gbxTimesheetDataETD.Controls.Add(this.label2);
            this.gbxTimesheetDataETD.Controls.Add(this.label1);
            this.gbxTimesheetDataETD.Location = new System.Drawing.Point(19, 16);
            this.gbxTimesheetDataETD.Name = "gbxTimesheetDataETD";
            this.gbxTimesheetDataETD.Size = new System.Drawing.Size(352, 84);
            this.gbxTimesheetDataETD.TabIndex = 4;
            this.gbxTimesheetDataETD.TabStop = false;
            this.gbxTimesheetDataETD.Text = "Timesheet Data";
            // 
            // txtSaturdayETD
            // 
            this.txtSaturdayETD.Location = new System.Drawing.Point(285, 50);
            this.txtSaturdayETD.Name = "txtSaturdayETD";
            this.txtSaturdayETD.Size = new System.Drawing.Size(36, 20);
            this.txtSaturdayETD.TabIndex = 13;
            // 
            // txtMondayETD
            // 
            this.txtMondayETD.Location = new System.Drawing.Point(75, 50);
            this.txtMondayETD.Name = "txtMondayETD";
            this.txtMondayETD.Size = new System.Drawing.Size(36, 20);
            this.txtMondayETD.TabIndex = 12;
            // 
            // txtTuesdayETD
            // 
            this.txtTuesdayETD.Location = new System.Drawing.Point(117, 50);
            this.txtTuesdayETD.Name = "txtTuesdayETD";
            this.txtTuesdayETD.Size = new System.Drawing.Size(36, 20);
            this.txtTuesdayETD.TabIndex = 11;
            // 
            // txtWednesdayETD
            // 
            this.txtWednesdayETD.Location = new System.Drawing.Point(159, 50);
            this.txtWednesdayETD.Name = "txtWednesdayETD";
            this.txtWednesdayETD.Size = new System.Drawing.Size(36, 20);
            this.txtWednesdayETD.TabIndex = 10;
            // 
            // txtThursdayETD
            // 
            this.txtThursdayETD.Location = new System.Drawing.Point(201, 50);
            this.txtThursdayETD.Name = "txtThursdayETD";
            this.txtThursdayETD.Size = new System.Drawing.Size(36, 20);
            this.txtThursdayETD.TabIndex = 9;
            // 
            // txtFridayETD
            // 
            this.txtFridayETD.Location = new System.Drawing.Point(243, 50);
            this.txtFridayETD.Name = "txtFridayETD";
            this.txtFridayETD.Size = new System.Drawing.Size(36, 20);
            this.txtFridayETD.TabIndex = 8;
            // 
            // txtSundayETD
            // 
            this.txtSundayETD.Location = new System.Drawing.Point(33, 50);
            this.txtSundayETD.Name = "txtSundayETD";
            this.txtSundayETD.Size = new System.Drawing.Size(36, 20);
            this.txtSundayETD.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(80, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Mon";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(293, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Sat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(253, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Fri";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(206, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Thu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(163, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Wed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tue";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sun";
            // 
            // frmEnterTimesheetData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 161);
            this.Controls.Add(this.btnCancelETD);
            this.Controls.Add(this.btnUpdateETD);
            this.Controls.Add(this.gbxTimesheetDataETD);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmEnterTimesheetData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Enter Timesheet Data";
            this.gbxTimesheetDataETD.ResumeLayout(false);
            this.gbxTimesheetDataETD.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancelETD;
        private System.Windows.Forms.Button btnUpdateETD;
        private System.Windows.Forms.GroupBox gbxTimesheetDataETD;
        private System.Windows.Forms.TextBox txtSaturdayETD;
        private System.Windows.Forms.TextBox txtMondayETD;
        private System.Windows.Forms.TextBox txtTuesdayETD;
        private System.Windows.Forms.TextBox txtWednesdayETD;
        private System.Windows.Forms.TextBox txtThursdayETD;
        private System.Windows.Forms.TextBox txtFridayETD;
        private System.Windows.Forms.TextBox txtSundayETD;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}