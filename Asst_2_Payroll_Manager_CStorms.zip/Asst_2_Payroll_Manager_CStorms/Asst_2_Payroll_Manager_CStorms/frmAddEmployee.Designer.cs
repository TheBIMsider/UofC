﻿namespace Asst_2_Payroll_Manager_CStorms
{
    partial class frmAddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddEmployee));
            this.gbxPersonalInformationAE = new System.Windows.Forms.GroupBox();
            this.labHourlyRate = new System.Windows.Forms.Label();
            this.labLastName = new System.Windows.Forms.Label();
            this.labFirstName = new System.Windows.Forms.Label();
            this.txtHourlyRateAE = new System.Windows.Forms.TextBox();
            this.txtLastNameAE = new System.Windows.Forms.TextBox();
            this.txtFirstNameAE = new System.Windows.Forms.TextBox();
            this.gbxTimesheetDataAE = new System.Windows.Forms.GroupBox();
            this.txtSaturdayAE = new System.Windows.Forms.TextBox();
            this.txtMondayAE = new System.Windows.Forms.TextBox();
            this.txtTuesdayAE = new System.Windows.Forms.TextBox();
            this.txtWednesdayAE = new System.Windows.Forms.TextBox();
            this.txtThursdayAE = new System.Windows.Forms.TextBox();
            this.txtFridayAE = new System.Windows.Forms.TextBox();
            this.txtSundayAE = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddAE = new System.Windows.Forms.Button();
            this.btnCancelAE = new System.Windows.Forms.Button();
            this.gbxPersonalInformationAE.SuspendLayout();
            this.gbxTimesheetDataAE.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxPersonalInformationAE
            // 
            this.gbxPersonalInformationAE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxPersonalInformationAE.Controls.Add(this.labHourlyRate);
            this.gbxPersonalInformationAE.Controls.Add(this.labLastName);
            this.gbxPersonalInformationAE.Controls.Add(this.labFirstName);
            this.gbxPersonalInformationAE.Controls.Add(this.txtHourlyRateAE);
            this.gbxPersonalInformationAE.Controls.Add(this.txtLastNameAE);
            this.gbxPersonalInformationAE.Controls.Add(this.txtFirstNameAE);
            this.gbxPersonalInformationAE.Location = new System.Drawing.Point(19, 16);
            this.gbxPersonalInformationAE.Name = "gbxPersonalInformationAE";
            this.gbxPersonalInformationAE.Size = new System.Drawing.Size(353, 134);
            this.gbxPersonalInformationAE.TabIndex = 0;
            this.gbxPersonalInformationAE.TabStop = false;
            this.gbxPersonalInformationAE.Text = "Personal Information";
            // 
            // labHourlyRate
            // 
            this.labHourlyRate.AutoSize = true;
            this.labHourlyRate.Location = new System.Drawing.Point(19, 100);
            this.labHourlyRate.Name = "labHourlyRate";
            this.labHourlyRate.Size = new System.Drawing.Size(66, 13);
            this.labHourlyRate.TabIndex = 5;
            this.labHourlyRate.Text = "Hourly Rate:";
            // 
            // labLastName
            // 
            this.labLastName.AutoSize = true;
            this.labLastName.Location = new System.Drawing.Point(19, 69);
            this.labLastName.Name = "labLastName";
            this.labLastName.Size = new System.Drawing.Size(61, 13);
            this.labLastName.TabIndex = 4;
            this.labLastName.Text = "Last Name:";
            // 
            // labFirstName
            // 
            this.labFirstName.AutoSize = true;
            this.labFirstName.Location = new System.Drawing.Point(19, 37);
            this.labFirstName.Name = "labFirstName";
            this.labFirstName.Size = new System.Drawing.Size(60, 13);
            this.labFirstName.TabIndex = 3;
            this.labFirstName.Text = "First Name:";
            // 
            // txtHourlyRateAE
            // 
            this.txtHourlyRateAE.Location = new System.Drawing.Point(128, 97);
            this.txtHourlyRateAE.Name = "txtHourlyRateAE";
            this.txtHourlyRateAE.Size = new System.Drawing.Size(100, 20);
            this.txtHourlyRateAE.TabIndex = 2;
            this.txtHourlyRateAE.TextChanged += new System.EventHandler(this.txtHourlyRate_TextChanged);
            // 
            // txtLastNameAE
            // 
            this.txtLastNameAE.Location = new System.Drawing.Point(128, 66);
            this.txtLastNameAE.Name = "txtLastNameAE";
            this.txtLastNameAE.Size = new System.Drawing.Size(200, 20);
            this.txtLastNameAE.TabIndex = 1;
            // 
            // txtFirstNameAE
            // 
            this.txtFirstNameAE.Location = new System.Drawing.Point(128, 34);
            this.txtFirstNameAE.Name = "txtFirstNameAE";
            this.txtFirstNameAE.Size = new System.Drawing.Size(200, 20);
            this.txtFirstNameAE.TabIndex = 0;
            // 
            // gbxTimesheetDataAE
            // 
            this.gbxTimesheetDataAE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxTimesheetDataAE.Controls.Add(this.txtSaturdayAE);
            this.gbxTimesheetDataAE.Controls.Add(this.txtMondayAE);
            this.gbxTimesheetDataAE.Controls.Add(this.txtTuesdayAE);
            this.gbxTimesheetDataAE.Controls.Add(this.txtWednesdayAE);
            this.gbxTimesheetDataAE.Controls.Add(this.txtThursdayAE);
            this.gbxTimesheetDataAE.Controls.Add(this.txtFridayAE);
            this.gbxTimesheetDataAE.Controls.Add(this.txtSundayAE);
            this.gbxTimesheetDataAE.Controls.Add(this.label7);
            this.gbxTimesheetDataAE.Controls.Add(this.label6);
            this.gbxTimesheetDataAE.Controls.Add(this.label5);
            this.gbxTimesheetDataAE.Controls.Add(this.label4);
            this.gbxTimesheetDataAE.Controls.Add(this.label3);
            this.gbxTimesheetDataAE.Controls.Add(this.label2);
            this.gbxTimesheetDataAE.Controls.Add(this.label1);
            this.gbxTimesheetDataAE.Location = new System.Drawing.Point(19, 163);
            this.gbxTimesheetDataAE.Name = "gbxTimesheetDataAE";
            this.gbxTimesheetDataAE.Size = new System.Drawing.Size(352, 84);
            this.gbxTimesheetDataAE.TabIndex = 1;
            this.gbxTimesheetDataAE.TabStop = false;
            this.gbxTimesheetDataAE.Text = "Timesheet Data";
            // 
            // txtSaturdayAE
            // 
            this.txtSaturdayAE.Location = new System.Drawing.Point(285, 50);
            this.txtSaturdayAE.Name = "txtSaturdayAE";
            this.txtSaturdayAE.Size = new System.Drawing.Size(36, 20);
            this.txtSaturdayAE.TabIndex = 13;
            // 
            // txtMondayAE
            // 
            this.txtMondayAE.Location = new System.Drawing.Point(75, 50);
            this.txtMondayAE.Name = "txtMondayAE";
            this.txtMondayAE.Size = new System.Drawing.Size(36, 20);
            this.txtMondayAE.TabIndex = 12;
            // 
            // txtTuesdayAE
            // 
            this.txtTuesdayAE.Location = new System.Drawing.Point(117, 50);
            this.txtTuesdayAE.Name = "txtTuesdayAE";
            this.txtTuesdayAE.Size = new System.Drawing.Size(36, 20);
            this.txtTuesdayAE.TabIndex = 11;
            // 
            // txtWednesdayAE
            // 
            this.txtWednesdayAE.Location = new System.Drawing.Point(159, 50);
            this.txtWednesdayAE.Name = "txtWednesdayAE";
            this.txtWednesdayAE.Size = new System.Drawing.Size(36, 20);
            this.txtWednesdayAE.TabIndex = 10;
            // 
            // txtThursdayAE
            // 
            this.txtThursdayAE.Location = new System.Drawing.Point(201, 50);
            this.txtThursdayAE.Name = "txtThursdayAE";
            this.txtThursdayAE.Size = new System.Drawing.Size(36, 20);
            this.txtThursdayAE.TabIndex = 9;
            // 
            // txtFridayAE
            // 
            this.txtFridayAE.Location = new System.Drawing.Point(243, 50);
            this.txtFridayAE.Name = "txtFridayAE";
            this.txtFridayAE.Size = new System.Drawing.Size(36, 20);
            this.txtFridayAE.TabIndex = 8;
            // 
            // txtSundayAE
            // 
            this.txtSundayAE.Location = new System.Drawing.Point(33, 50);
            this.txtSundayAE.Name = "txtSundayAE";
            this.txtSundayAE.Size = new System.Drawing.Size(36, 20);
            this.txtSundayAE.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(80, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Mon";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(293, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Sat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(253, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Fri";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(206, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Thu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(163, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Wed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tue";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sun";
            // 
            // btnAddAE
            // 
            this.btnAddAE.Location = new System.Drawing.Point(198, 276);
            this.btnAddAE.Name = "btnAddAE";
            this.btnAddAE.Size = new System.Drawing.Size(75, 23);
            this.btnAddAE.TabIndex = 2;
            this.btnAddAE.Text = "Add";
            this.btnAddAE.UseVisualStyleBackColor = true;
            // 
            // btnCancelAE
            // 
            this.btnCancelAE.Location = new System.Drawing.Point(296, 276);
            this.btnCancelAE.Name = "btnCancelAE";
            this.btnCancelAE.Size = new System.Drawing.Size(75, 23);
            this.btnCancelAE.TabIndex = 3;
            this.btnCancelAE.Text = "Cancel";
            this.btnCancelAE.UseVisualStyleBackColor = true;
            // 
            // frmAddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 311);
            this.Controls.Add(this.btnCancelAE);
            this.Controls.Add(this.btnAddAE);
            this.Controls.Add(this.gbxTimesheetDataAE);
            this.Controls.Add(this.gbxPersonalInformationAE);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmAddEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Add Employee";
            this.gbxPersonalInformationAE.ResumeLayout(false);
            this.gbxPersonalInformationAE.PerformLayout();
            this.gbxTimesheetDataAE.ResumeLayout(false);
            this.gbxTimesheetDataAE.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxPersonalInformationAE;
        private System.Windows.Forms.Label labHourlyRate;
        private System.Windows.Forms.Label labLastName;
        private System.Windows.Forms.Label labFirstName;
        private System.Windows.Forms.TextBox txtHourlyRateAE;
        private System.Windows.Forms.TextBox txtLastNameAE;
        private System.Windows.Forms.TextBox txtFirstNameAE;
        private System.Windows.Forms.GroupBox gbxTimesheetDataAE;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSaturdayAE;
        private System.Windows.Forms.TextBox txtMondayAE;
        private System.Windows.Forms.TextBox txtTuesdayAE;
        private System.Windows.Forms.TextBox txtWednesdayAE;
        private System.Windows.Forms.TextBox txtThursdayAE;
        private System.Windows.Forms.TextBox txtFridayAE;
        private System.Windows.Forms.TextBox txtSundayAE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddAE;
        private System.Windows.Forms.Button btnCancelAE;
    }
}